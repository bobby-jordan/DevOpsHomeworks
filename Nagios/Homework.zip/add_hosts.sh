#!/bin/bash

echo "192.168.99.100 master master" >> /etc/hosts
echo "192.168.99.101 nodeone nodeone" >> /etc/hosts
echo "192.168.99.102 nodetwo nodetwo" >> /etc/hosts
